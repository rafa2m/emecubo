
  SDL_Weather_80422 - C++ Class Library for: 
  SwitchDoc Labs WeatherRack
  Argent Data Systems
  SparkFun Weather Station 
  Created by SwitchDoc Labs July 27, 2014.
  Released into the public domain.

  Version 1.1
  August 18, 2014
  
  Version 1.2 - updated constants to suppport 3.3V
  Version 1.6 - Support for ADS1015 in WeatherPiArduino Board February 7, 2015

  
